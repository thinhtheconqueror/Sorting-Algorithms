def quick_sort(a, l : int, r : int) :
    pivot = a[(l + r) // 2]
    i, j = l, r
    while i < j :
        while a[i] < pivot :
            i += 1
        while a[j] > pivot :
            j -= 1
        if i <= j :
            a[i], a[j] = a[j], a[i]
            i += 1
            j -= 1
    if i < r :
        quick_sort(a, i, r)
    if l < j :
        quick_sort(a, l, j)
