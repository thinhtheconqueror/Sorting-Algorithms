import numpy as np
arr = np.array([2, 4, 3, 8])
sorted = np.sort(arr)
print(sorted)