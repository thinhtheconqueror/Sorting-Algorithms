def merge_array(a, left : int, mid : int, right : int) :
    
    n1 = mid - left + 1
    n2 = right - mid

    left_array = [0] * n1
    right_array = [0] * n2

    for i in range(0, n1) :
        left_array[i] = a[i + left]
    for j in range(0, n2) :
        right_array[j] = a[mid + 1 + j] 

    i, j = 0, 0
    k = left

    while i < n1 and j < n2 :
        if left_array[i] <= right_array[j] :
            a[k] = left_array[i]
            i += 1
        else :
            a[k] = right_array[j]
            j += 1
        k += 1

    while i < n1 :
        a[k] = left_array[i]
        i += 1
        k += 1
    
    while j < n2 :
        a[k] = right_array[j]
        j += 1
        k += 1
        
def merge_sort(a, left : int, right : int) :
    
    if (left >= right) :
        return
    
    mid = (left + right) // 2
    merge_sort(a, left, mid)
    merge_sort(a, mid+1, right)
    merge_array(a, left, mid, right)


